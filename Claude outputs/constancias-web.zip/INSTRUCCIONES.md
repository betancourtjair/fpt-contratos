# Constancias de Membresía FPT — Web

Página interna para generar constancias y contratos firmados de hasta **2,500 socios por lote**.
Login con cuenta Microsoft @fpt.com.mx. Cada lote entrega un ZIP con:

- `…_constancia.pdf`: constancia de membresía de cada socio
- `…_contrato.pdf`: contrato firmado. Socios normales: el formulario "Contrato" con la firma verificada. Migrados: el PDF de la Galería
- `resumen.csv`: una fila por búsqueda (con contrato / sin contrato / no encontrado)

Creado por Jair Betancourt

---

## Despliegue (una sola vez, ~20 min)

1. **Instala Azure CLI**: https://aka.ms/installazurecliwindows (luego cierra y abre PowerShell).
2. En PowerShell, entra a esta carpeta y ejecuta:
   ```powershell
   cd "C:\Users\JairPulidoBetancourt\Downloads\Proyectos Desarrollo Jair\Zenoti\web"
   .\deploy\desplegar.ps1
   ```
   Si Windows bloquea el script: `Set-ExecutionPolicy -Scope Process Bypass` y repite.
   Te pedirá la **API key**, el **usuario** y la **contraseña** de la cuenta de servicio de Zenoti.
   Se guardan cifrados en la configuración de la Web App; no quedan en ningún archivo.
3. **Login con Microsoft** (portal de Azure):
   1. portal.azure.com → App Services → **constancias-fpt** → **Autenticación** → **Agregar proveedor de identidades**
   2. Proveedor: **Microsoft**. Registro de aplicación: **Crear nuevo**. Tipos de cuenta: **Solo este directorio (inquilino único)**.
   3. Acceso: **Requerir autenticación**. Solicitudes no autenticadas: **HTTP 302 → redirigir a la página de inicio de sesión**.
   4. Guardar.
   5. (Opcional, recomendado) Para limitar quién entra: Entra ID → Aplicaciones empresariales → *constancias-fpt* →
      Propiedades → **¿Se requiere asignación? = Sí** → Usuarios y grupos → agrega a los usuarios o al grupo autorizado.
4. Abre `https://constancias-fpt.azurewebsites.net`, inicia sesión y prueba con 2 o 3 socios conocidos
   (uno normal y uno migrado, p. ej. `5576145775` y `8147125866`).

## Primera prueba: qué revisar

- **Zenoti restringe por país.** Por eso todo va en la región **Mexico Central**. Si el script dice que la región no está
  disponible, avísame antes de usar otra.
- **Inicio de sesión de la cuenta de servicio.** Si el resultado dice "No se pudo iniciar sesión en Zenoti…", revisa:
  usuario y contraseña, que la cuenta **no tenga verificación en dos pasos** y que tenga permiso de ver perfiles, planes
  y galería de invitados.
- Bitácora en vivo: portal → App Service → **Flujo de registro** (Log stream). Cada lote registra quién lo hizo.

## Uso

- Pega un socio por línea (teléfono, correo, ID de cliente o **número de factura**) o carga un Excel/CSV (se toma la primera columna).
- **Por factura:** `3373/R222525` busca la factura en Zenoti (como Agenda → Más → Buscar Factura / # Recibo), toma al
  cliente y genera lo mismo. También sirve el # de recibo. Para verificar, agrega teléfono o correo en la misma línea:
  `3373/R222525 2221926250`. Si no coincide, sale como "No encontrado" con el nombre real del titular.
  El prefijo (3373) es el club; la primera vez recorre los 60 clubes (~7 s) y después lo recuerda.
- Hasta 2,500 por lote. Tiempo aproximado: **6 a 10 segundos por socio** (2,500 socios ≈ 4 a 7 horas).
  Puedes cerrar la página: el lote sigue en el servidor y aparece en **Mis lotes recientes**.
- **Descargar avance** baja un ZIP con lo que ya esté listo, sin esperar a que termine.
- Los lotes se atienden en fila (uno a la vez) y se borran a los 7 días.
- Si el servidor se reinicia a media corrida, el lote continúa desde donde se quedó.

## Actualizar el código

```powershell
.\deploy\actualizar.ps1
```

## Costos aproximados (confirmar en la calculadora de Azure)

- App Service Linux **B2**: ~US$26/mes · Container Registry Basic: ~US$5/mes.

## Configuración (App Service → Variables de entorno)

| Variable | Uso |
|---|---|
| `ZENOTI_API_KEY` | API key de la app de Zenoti |
| `ZENOTI_USUARIO` / `ZENOTI_PASSWORD` | Cuenta de servicio de Zenoti (para descargar contratos) |
| `MAX_POR_LOTE` | Máximo de socios por lote (2500) |
| `HORAS_RETENCION` | Horas que se conservan los ZIP (168 = 7 días) |
| `DOMINIO_PERMITIDO` | Dominio de las cuentas que pueden entrar (fpt.com.mx) |
| `USAR_NAVEGADOR` | `0` para solo constancias sin descargar contratos |
