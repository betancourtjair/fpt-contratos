# =====================================================================
#  Constancias de Membresía FPT - despliegue en Azure App Service
#  Ejecutar desde la carpeta del proyecto (donde está el Dockerfile):
#     .\deploy\desplegar.ps1
#  Requisitos: Azure CLI (https://aka.ms/installazurecliwindows) y ser admin de la suscripción.
#  No necesitas Docker: la imagen se construye en Azure (az acr build).
# =====================================================================
param(
  [string]$Grupo    = "rg-constancias-fpt",
  [string]$Region   = "mexicocentral",          # Zenoti bloquea accesos fuera de México
  [string]$Registro = "acrconstanciasfpt",      # nombre único global, solo minúsculas y números
  [string]$Plan     = "plan-constancias-fpt",
  [string]$App      = "constancias-fpt",        # será https://<App>.azurewebsites.net
  [string]$Sku      = "B2"                      # 2 núcleos / 3.5 GB (Chromium necesita memoria)
)
$ErrorActionPreference = "Stop"
$Imagen = "constancias:v1"

Write-Host "`n== 1. Sesión de Azure ==" -ForegroundColor Cyan
az account show --query "{suscripcion:name, tenant:tenantId}" -o table 2>$null
if ($LASTEXITCODE -ne 0) { az login | Out-Null; az account show --query "{suscripcion:name}" -o table }

Write-Host "`n== 2. Verificando que la región $Region tenga App Service Linux $Sku ==" -ForegroundColor Cyan
$ok = az appservice list-locations --sku $Sku --linux-workers-enabled --query "[?name=='Mexico Central'].name" -o tsv
if ($Region -eq "mexicocentral" -and -not $ok) {
  Write-Host "Mexico Central no ofrece App Service Linux $Sku en tu suscripción." -ForegroundColor Yellow
  Write-Host "Zenoti restringe accesos por país; NO uses una región fuera de México sin probar primero." -ForegroundColor Yellow
  exit 1
}

Write-Host "`n== 3. Grupo de recursos y registro de contenedores ==" -ForegroundColor Cyan
az group create -n $Grupo -l $Region -o none
az acr create -g $Grupo -n $Registro --sku Basic -l $Region -o none

Write-Host "`n== 4. Construyendo la imagen en Azure (tarda ~5-8 min) ==" -ForegroundColor Cyan
az acr build -r $Registro -t $Imagen .

Write-Host "`n== 5. Plan y Web App ==" -ForegroundColor Cyan
az appservice plan create -g $Grupo -n $Plan --is-linux --sku $Sku -l $Region -o none
az webapp create -g $Grupo -p $Plan -n $App --container-image-name "$Registro.azurecr.io/$Imagen" -o none

# La Web App baja la imagen con su identidad administrada (sin contraseñas)
$principal = az webapp identity assign -g $Grupo -n $App --query principalId -o tsv
$acrId = az acr show -n $Registro --query id -o tsv
az role assignment create --assignee-object-id $principal --assignee-principal-type ServicePrincipal --role AcrPull --scope $acrId -o none
az webapp config set -g $Grupo -n $App --generic-configurations '{\"acrUseManagedIdentityCreds\": true}' -o none
az webapp config set -g $Grupo -n $App --always-on true --http20-enabled true -o none
az webapp update -g $Grupo -n $App --https-only true -o none

Write-Host "`n== 6. Secretos y configuración ==" -ForegroundColor Cyan
function Leer-Secreto($texto) {
  $s = Read-Host $texto -AsSecureString
  [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
}
$apiKey  = Leer-Secreto "API key de Zenoti (Test apikey / app de constancias)"
$usuario = Read-Host  "Usuario de la cuenta de servicio de Zenoti"
$pass    = Leer-Secreto "Contraseña de la cuenta de servicio de Zenoti"

az webapp config appsettings set -g $Grupo -n $App -o none --settings `
  WEBSITES_PORT=8000 `
  WEBSITES_ENABLE_APP_SERVICE_STORAGE=true `
  WEBSITES_CONTAINER_START_TIME_LIMIT=600 `
  TZ=America/Mexico_City `
  REQUIERE_LOGIN=1 `
  DOMINIO_PERMITIDO=fpt.com.mx `
  MAX_POR_LOTE=2500 `
  HORAS_RETENCION=168 `
  "ZENOTI_API_KEY=$apiKey" `
  "ZENOTI_USUARIO=$usuario" `
  "ZENOTI_PASSWORD=$pass"
$apiKey = $null; $pass = $null

az webapp restart -g $Grupo -n $App -o none
Write-Host "`nListo. URL: https://$App.azurewebsites.net" -ForegroundColor Green
Write-Host "FALTA el paso 7 (login con Microsoft) en el portal: ver INSTRUCCIONES.md" -ForegroundColor Yellow
