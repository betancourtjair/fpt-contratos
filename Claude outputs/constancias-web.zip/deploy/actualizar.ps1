# Publica una nueva versión del código (después de cambiar algo en app/).
#   .\deploy\actualizar.ps1
param(
  [string]$Grupo    = "rg-constancias-fpt",
  [string]$Registro = "acrconstanciasfpt",
  [string]$App      = "constancias-fpt"
)
$ErrorActionPreference = "Stop"
$version = Get-Date -Format "yyyyMMddHHmm"
az acr build -r $Registro -t "constancias:$version" -t "constancias:v1" .
az webapp config container set -g $Grupo -n $App --container-image-name "$Registro.azurecr.io/constancias:$version" -o none
az webapp restart -g $Grupo -n $App -o none
Write-Host "Versión $version publicada en https://$App.azurewebsites.net" -ForegroundColor Green
Write-Host "Ojo: si había un lote en proceso, continúa solo desde donde se quedó." -ForegroundColor Yellow
