// Cliente para la API REST de Documenso (https://documenso.com) — instancia AUTO-HOSPEDADA
// en Render. Documentación: https://docs.documenso.com/docs/developers/api
//
// Reemplaza por completo a la integración anterior con DocuSeal. Se cambió de proveedor
// porque DocuSeal, en su edición Community (auto-hospedada, gratis), bloquea justo el
// endpoint que esta app necesita — crear una firma nueva a partir de un PDF recién subido —
// detrás de su plan de pago ("Pro Edition"; confirmado en vivo y en su documentación oficial:
// POST /submissions/pdf y POST /templates/pdf están marcados "Pro"). Documenso deja esa
// funcionalidad núcleo (POST /envelope/create) en su edición Community, sin límite de
// documentos ni llave de licencia. Lo que sí es exclusivo de su edición Enterprise (SSO/SAML,
// agrupar varios documentos distintos en un mismo envío, certificaciones tipo SOC2/HIPAA,
// marca blanca) no lo usa esta app.
//
// *** IMPORTANTE — DIFERENCIA LEGAL (igual que con DocuSeal antes) ***
// Documenso NO está certificado como Proveedor de Servicios de Certificación (PSC) bajo la
// NOM-151 mexicana: es firma electrónica SIMPLE (registra quién firmó, cuándo y desde qué IP),
// no firma con validez NOM-151 como sí tenía doc2sign. Esta app y su UI deben dejarlo claro al
// usuario final (ver el aviso en EnviarAFirmarModal.jsx). Es una decisión consciente de costo
// vs. certeza legal, confirmada por el usuario.
//
// Variables de entorno requeridas:
//   DOCUMENSO_URL          URL base de la instancia self-hosted, SIN "/" al final
//                          (ej. https://fpt-documenso.onrender.com).
//   DOCUMENSO_API_TOKEN    Token de API. Se genera dentro de la instancia ya levantada: ícono
//                          de usuario (arriba a la derecha) > Configuración de equipo > API
//                          Tokens. Ojo: los tokens de API requieren un "Team" — una cuenta
//                          personal de Documenso no puede generarlos.
// Opcional (recomendado):
//   DOCUMENSO_WEBHOOK_SECRET  Secreto para verificar que los webhooks realmente vienen de esa
//                             instancia (dentro de Documenso: Configuración de equipo >
//                             Webhooks). A diferencia de DocuSeal (HMAC-SHA256 con timestamp),
//                             Documenso manda este secreto tal cual en el header
//                             "X-Documenso-Secret" — ver routes/documensoWebhook.js.
//
// A diferencia de doc2sign y de DocuSeal, Documenso no maneja "tipos de documento" configurados
// de antemano en la cuenta: cualquier PDF se manda directo a firmar (POST /envelope/create),
// sin catálogo. Tampoco hay conceptos de "usuario de servicio" separados — el token de API ya
// identifica a toda la cuenta/equipo.
//
// La posición del campo de firma en el PDF se manda como porcentaje (0-100) del tamaño de la
// página (a diferencia de DocuSeal, que usaba fracción 0-1), con origen (0,0) en la esquina
// superior izquierda — confirmado en la documentación oficial (docs.documenso.com/docs/
// developers/api/fields, sección "Field Positioning"): esos porcentajes son relativos al tamaño
// real de la página en cuestión, así que se comportan igual sin importar el tamaño u orientación
// del PDF. Desde el editor visual en EnviarAFirmarModal.jsx (arrastrar un recuadro sobre el PDF
// renderizado con pdfjs-dist) cada firmante trae su propia `area` ya en ese mismo formato — ver
// `f.area` en crearSubmission() más abajo. Si no la trae (petición vieja, o uso directo del API
// sin pasar por la UI), se usa `areaPorDefecto(idx)`, que apila una firma debajo de otra en la
// primera página.

function baseUrl() {
    return (process.env.DOCUMENSO_URL || '').replace(/\/+$/, '');
}

function configurado() {
    return Boolean(baseUrl() && process.env.DOCUMENSO_API_TOKEN);
}

async function llamar(metodo, path, { body, form } = {}) {
    if (!configurado()) {
          throw new Error('Faltan DOCUMENSO_URL / DOCUMENSO_API_TOKEN en las variables de entorno.');
    }
    const headers = { Authorization: process.env.DOCUMENSO_API_TOKEN };
    let requestBody;
    if (form) {
          requestBody = form; // FormData nativo: fetch calcula el boundary multipart solo.
    } else if (body) {
          headers['Content-Type'] = 'application/json';
          requestBody = JSON.stringify(body);
    }
    const resp = await fetch(`${baseUrl()}${path}`, { method: metodo, headers, body: requestBody });
    const contentType = resp.headers.get('content-type') || '';
    const texto = await resp.text();
    let data = texto;
    if (contentType.includes('application/json')) {
          try {
                  data = JSON.parse(texto);
          } catch {
                  /* se deja el texto crudo */
          }
    }
    if (!resp.ok) {
          const detalle = typeof data === 'string' ? data : JSON.stringify(data);
          throw new Error(`Documenso respondió ${resp.status} en ${metodo} ${path}: ${detalle}`);
    }
    return data;
}

function nombreCompleto(f) {
    return (f.nombreCompleto || '').trim();
}

/**
 * Área (porcentaje 0-100 del tamaño de página) por defecto para ir apilando firmas en la
 * primera página, de arriba hacia abajo; si hay más de 6 firmantes se pasa a una segunda
 * "columna" en X para no salirse de la página.
 */
function areaPorDefecto(idx) {
    const porColumna = 6;
    const fila = idx % porColumna;
    const columna = Math.floor(idx / porColumna);
    return {
          page: 1,
          positionX: 6 + columna * 34,
          positionY: 88 - fila * 9,
          width: 28,
          height: 6,
    };
}

/**
 * Envía un documento a firma: crea un "envelope" nuevo a partir de un PDF (sin plantilla
 * previa), un firmante (recipient) por cada elemento de `datos.firmantes`, y luego lo
 * DISTRIBUYE para que Documenso realmente mande los correos de invitación.
 *
 * *** BUG CORREGIDO (prueba final de firmas, sep 2026) ***
 * A diferencia de DocuSeal (que mandaba el correo de invitación con una sola llamada),
 * Documenso separa "crear" de "enviar" en dos pasos: POST /envelope/create solo deja el
 * envelope en estatus DRAFT dentro de Documenso — nadie recibe nada todavía, aunque los
 * firmantes ya queden cargados correctamente. Hay que llamar explícitamente a
 * POST /envelope/distribute para que se dispare el envío real. Confirmado leyendo el código
 * fuente de Documenso (self-hosted, AGPL-3.0):
 *   - packages/trpc/server/envelope-router/distribute-envelope.ts es lo único que llama a
 *     sendDocument() (el que de verdad manda los correos); create-envelope.ts nunca lo llama.
 *   - packages/prisma/schema.prisma, enum DocumentSigningOrder = PARALLEL (default) |
 *     SEQUENTIAL — el "signingOrder" numérico de cada firmante se IGNORA si no se manda también
 *     "meta.signingOrder = 'SEQUENTIAL'" al crear el envelope; si no, Documenso los trata como
 *     PARALLEL sin importar los números.
 * Antes de esta corrección, el envelope se creaba con los firmantes correctos (visible en la UI
 * de Documenso) pero se quedaba en borrador para siempre y ningún firmante recibía correo.
 *
 * @param {{
 *   base64PDF: string,
 *   nombreDocumento: string,
 *   ordenada: boolean,
    *   vencimientoDias?: number,
    *   firmantes: Array<{nombreCompleto: string, email: string, orden: number, area?: {page: number, positionX: number, positionY: number, width: number, height: number}}>,
    * }} datos
    * @returns {Promise<{submissionId: string, submitters: Array<{email: string, slug: string, embedSrc: string}>}>}
 */
async function crearSubmission(datos) {
    if (!Array.isArray(datos.firmantes) || datos.firmantes.length === 0) {
          throw new Error('Se requiere al menos un firmante.');
    }
    // Días antes de que el enlace de firma de cada firmante deje de funcionar (Documenso:
    // envelopeExpirationPeriod). Documenso no cancela el envelope solo por esto — cuando vence,
    // al dueño (esta cuenta de servicio) le llega un correo avisando, y desde ahí se puede
    // reenviar (lo que extiende el vencimiento) o cancelar. Ver cancelarSubmission arriba para
    // cancelar desde esta misma app.
    const vencimientoDias = Number.isFinite(Number(datos.vencimientoDias)) ? Number(datos.vencimientoDias) : 2;

  const recipients = datos.firmantes.map((f, idx) => ({
        email: f.email,
        name: nombreCompleto(f) || f.email,
        role: 'SIGNER',
        // Si "ordenada" es true, cada firmante solo recibe el correo de invitación hasta que el
        // anterior termine (orden real: signingOrder ascendente). Si no, se manda el mismo valor a
        // todos para que Documenso los notifique en paralelo (cualquiera puede firmar primero).
        // OJO: este número por sí solo no basta, ver "meta.signingOrder" abajo.
        signingOrder: datos.ordenada ? idx + 1 : 1,
        fields: [
          {
                    type: 'SIGNATURE',
                    // Recuadro dibujado a mano por el usuario en el editor visual; si no vino
                    // (petición vieja o uso directo del API), se cae a la posición automática.
                    ...(f.area || areaPorDefecto(idx)),
          },
              ],
  }));

  const payload = {
        type: 'DOCUMENT',
        title: datos.nombreDocumento,
        recipients,
        // Sin esto, Documenso ignora el signingOrder de cada firmante (su default es PARALLEL) y
        // notifica a todos al mismo tiempo, sin importar el orden que se haya mandado arriba.
        meta: {
                signingOrder: datos.ordenada ? 'SEQUENTIAL' : 'PARALLEL',
                // Vencimiento del enlace de firma (1 o 2 días, elegido en EnviarAFirmarModal.jsx).
                envelopeExpirationPeriod: { unit: 'day', amount: vencimientoDias },
                // Recordatorio nativo de Documenso: un solo correo de recordatorio a quien no haya
                // firmado, 24 horas (1 día — el API no maneja unidades más finas que "day") después
                // de haberse enviado. repeatEvery deshabilitado para que sea un único recordatorio,
                // no uno cada N días.
                reminderSettings: {
                        sendAfter: { unit: 'day', amount: 1 },
                        repeatEvery: { disabled: true },
                },
        },
  };

  const form = new FormData();
    form.append('payload', JSON.stringify(payload));
    form.append(
          'files',
          new Blob([Buffer.from(datos.base64PDF, 'base64')], { type: 'application/pdf' }),
          `${datos.nombreDocumento}.pdf`
        );

  const creado = await llamar('POST', '/api/v2/envelope/create', { form });
    if (!creado?.id) {
          throw new Error(`Documenso no regresó un id de envelope válido: ${JSON.stringify(creado)}`);
    }


  let distribuido;
    try {
          distribuido = await llamar('POST', '/api/v2/envelope/distribute', {
                  body: { envelopeId: creado.id },
          });
    } catch (err) {
          // El envelope SÍ quedó creado en Documenso (con id creado.id) pero no se pudo distribuir —
      // se deja bien claro en el mensaje para no confundirlo con una falla de creación, ya que
      // requiere revisar/reintentar puntualmente ese envelope en vez de mandar todo de nuevo.
      throw new Error(
              `El documento se creó en Documenso (envelope ${creado.id}) pero no se pudo enviar a los ` +
                `firmantes: ${err.message}`
            );
    }

  return {
        submissionId: String(creado.id),
        submitters: Array.isArray(distribuido?.recipients)
          ? distribuido.recipients.map((r) => ({ email: r.email, slug: r.token, embedSrc: r.signingUrl }))
                : [],
  };
}

/** Consulta el detalle/estatus actual de un envelope (fuente de verdad, nunca el webhook). */
async function consultarSubmission(submissionId) {
    return llamar('GET', `/api/v2/envelope/${submissionId}`);
}

/**
 * Cancela un envelope que sigue en proceso (estatus DRAFT o PENDING) — por ejemplo, si se mandó
 * por error o ya no se necesita la firma. A diferencia de "rechazar" (que dispara el propio
 * firmante desde su pantalla de firma), esto lo dispara un usuario interno de esta app desde el
 * expediente del contrato. Confirmado en el código fuente de Documenso (self-hosted, AGPL-3.0):
 * packages/trpc/server/envelope-router/cancel-envelope.types.ts expone esta mutación en la API
 * pública como POST /envelope/cancel, con body { envelopeId, reason? } (el motivo es opcional).
 * Documenso deja el envelope con estatus CANCELLED (visible en su propio historial) en vez de
 * borrarlo — no existe una operación de "delete" real vía este cliente porque no la usa la app.
 */
async function cancelarSubmission(submissionId, motivo) {
    return llamar('POST', '/api/v2/envelope/cancel', {
          body: { envelopeId: submissionId, reason: motivo || undefined },
    });
}

/**
 * Descarga el PDF ya firmado (con firmas y bitácora de auditoría insertadas) en bytes.
 *
 * *** CORREGIDO tras probar en vivo (sep 2026) ***
 * La primera versión de esta función asumía, según los ejemplos fragmentados de la
 * documentación pública (ver github.com/documenso/documenso/issues/2817), que GET /envelope/:id
 * traía una URL de descarga en algún campo del JSON (se probaban varios nombres candidatos). En
 * la práctica, un envelope COMPLETED no trae ninguna URL: solo trae, dentro de envelopeItems[],
 * el id de cada "item" (el PDF adjunto al envelope) — la descarga real es un endpoint APARTE que
 * regresa los BYTES del PDF directamente (Content-Type: application/pdf, no JSON). Confirmado
 * leyendo el código fuente de Documenso (self-hosted, AGPL-3.0):
 * packages/trpc/server/envelope-router/download-envelope-item.types.ts documenta
 * GET /envelope/item/:envelopeItemId/download?version=signed|original|pending (la
 * implementación real vive en su servidor Hono/Remix — el procedimiento de tRPC solo declara el
 * contrato para la API pública v2 y truena "NOT_IMPLEMENTED" si se llama por tRPC directo).
 */
async function descargarDocumento(submissionId) {
    const data = await consultarSubmission(submissionId);
    const envelopeItemId = data?.envelopeItems?.[0]?.id;
    if (!envelopeItemId) {
          throw new Error(
                  `El envelope ${submissionId} no trae ningún envelopeItem del que descargar el PDF. ` +
                    `Respuesta: ${JSON.stringify(data)}`
                );
    }
    const resp = await fetch(`${baseUrl()}/api/v2/envelope/item/${envelopeItemId}/download?version=signed`, {
          headers: { Authorization: process.env.DOCUMENSO_API_TOKEN },
    });
    if (!resp.ok) {
          const detalle = await resp.text().catch(() => '');
          throw new Error(`No se pudo descargar el documento de Documenso (${resp.status}): ${detalle}`);
    }
    return Buffer.from(await resp.arrayBuffer());
}

/**
 * Extiende el vencimiento del enlace de firma de un envelope que sigue en proceso, EXACTAMENTE
 * `dias` días a partir de ahora (botón "Extender 2 días" en el frontend, mientras sigue "En
 * firma") — sin importar cuántos días se hayan configurado originalmente al enviarlo.
 *
 * Documenso no expone una operación de "extender" directa. Se combinan dos llamadas de su API
 * (ambas confirmadas leyendo el código fuente, self-hosted, AGPL-3.0):
 *   1. POST /envelope/update, con meta.envelopeExpirationPeriod — packages/lib/types/
 *      document-meta.ts confirma que ZDocumentMetaUpdateSchema es literalmente
 *      ZDocumentMetaCreateSchema (el mismo esquema que usa crearSubmission arriba), así que
 *      también acepta envelopeExpirationPeriod. Esto reconfigura el envelope para que, de ahí en
 *      adelante, "vencimiento" signifique "dias" días — pero por sí sola esta llamada NO mueve la
 *      fecha de vencimiento (expiresAt) de los firmantes que ya la tenían fija desde el envío
 *      original.
 *   2. POST /envelope/redistribute, con la lista de recipients (ids numéricos, NO su email) que
 *      todavía no firman. packages/trpc/server/envelope-router/resend-document.ts (la
 *      implementación real detrás de este endpoint) es lo que de verdad recalcula
 *      expiresAt = ahora + envelope.documentMeta.envelopeExpirationPeriod (el que se acaba de
 *      dejar en el paso 1) para cada uno de esos recipients, limpia expirationNotifiedAt y les
 *      reenvía el correo de invitación — por eso hay que llamar primero a "update" y luego a
 *      "redistribute", nunca al revés ni solo uno de los dos.
 * Los recipients ya firmados (signingStatus 'SIGNED') o con role 'CC' se excluyen antes de
 * mandarlos, igual que hace resend-document.ts internamente — mandarlos de todas formas no rompe
 * nada (Documenso los ignora) pero así el log de este cliente refleja a quién realmente se le
 * extendió el plazo.
 *
 * @returns {Promise<{recipientsExtendidos: Array<{email:string,nombreCompleto:string}>}>}
 */
async function extenderVencimiento(submissionId, dias) {
    const diasValidos = Number.isFinite(Number(dias)) && Number(dias) > 0 ? Number(dias) : 2;

    await llamar('POST', '/api/v2/envelope/update', {
          body: {
                envelopeId: submissionId,
                meta: { envelopeExpirationPeriod: { unit: 'day', amount: diasValidos } },
          },
    });

    const envelope = await consultarSubmission(submissionId);
    const pendientes = (envelope?.recipients || []).filter(
          (r) => r.role !== 'CC' && r.signingStatus !== 'SIGNED'
    );
    if (pendientes.length === 0) {
          return { recipientsExtendidos: [] };
    }

    await llamar('POST', '/api/v2/envelope/redistribute', {
          body: { envelopeId: submissionId, recipients: pendientes.map((r) => r.id) },
    });

    return {
          recipientsExtendidos: pendientes.map((r) => ({ email: r.email, nombreCompleto: r.name || r.email })),
    };
}

module.exports = {
    configurado,
    crearSubmission,
    consultarSubmission,
    descargarDocumento,
    cancelarSubmission,
    extenderVencimiento,
};
