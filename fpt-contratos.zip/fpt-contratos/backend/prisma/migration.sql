-- FPT Contratos - Plataforma de Gestión Contractual
-- Migración inicial (SQL escrito a mano; Prisma Client no se usa en runtime porque la
-- descarga del query engine está bloqueada en algunos entornos de desarrollo/sandbox.
-- prisma/schema.prisma se conserva como documentación del modelo de datos).

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE rol_usuario AS ENUM ('super_admin', 'admin', 'juridico', 'aprobador', 'solicitante', 'lectura');
CREATE TYPE estatus_contrato AS ENUM ('borrador', 'en_revision', 'en_autorizacion', 'rechazado', 'autorizado', 'activo', 'por_vencer', 'vencido', 'cancelado');
CREATE TYPE decision_aprobacion AS ENUM ('pendiente', 'aprobado', 'rechazado', 'omitido');
CREATE TYPE categoria_documento AS ENUM ('borrador', 'version_firmada', 'anexo', 'evidencia', 'otro');

CREATE TABLE usuarios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  nombre TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  rol rol_usuario NOT NULL DEFAULT 'solicitante',
  area TEXT,
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE tipos_contrato (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT UNIQUE NOT NULL,
  descripcion TEXT,
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE flujo_plantillas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT NOT NULL,
  tipo_contrato_id UUID REFERENCES tipos_contrato(id),
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE flujo_pasos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plantilla_id UUID NOT NULL REFERENCES flujo_plantillas(id) ON DELETE CASCADE,
  orden INT NOT NULL,
  nombre TEXT NOT NULL,
  rol_aprobador rol_usuario,
  aprobador_id UUID REFERENCES usuarios(id),
  monto_minimo NUMERIC(14,2),
  monto_maximo NUMERIC(14,2),
  obligatorio BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE (plantilla_id, orden),
  CHECK (rol_aprobador IS NOT NULL OR aprobador_id IS NOT NULL)
);

CREATE TABLE contratos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  folio TEXT UNIQUE NOT NULL,
  titulo TEXT NOT NULL,
  descripcion TEXT,
  tipo_contrato_id UUID NOT NULL REFERENCES tipos_contrato(id),
  parte TEXT NOT NULL,
  contraparte_nombre TEXT NOT NULL,
  contraparte_rfc TEXT,
  contraparte_contacto TEXT,
  contraparte_email TEXT,
  monto NUMERIC(14,2),
  moneda TEXT NOT NULL DEFAULT 'MXN',
  fecha_inicio DATE,
  fecha_fin DATE,
  renovacion_automatica BOOLEAN NOT NULL DEFAULT FALSE,
  dias_aviso_vencimiento INT NOT NULL DEFAULT 30,
  estatus estatus_contrato NOT NULL DEFAULT 'borrador',
  solicitado_por_id UUID NOT NULL REFERENCES usuarios(id),
  plantilla_flujo_id UUID REFERENCES flujo_plantillas(id),
  paso_actual_orden INT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_contratos_estatus ON contratos(estatus);
CREATE INDEX idx_contratos_fecha_fin ON contratos(fecha_fin);
CREATE INDEX idx_contratos_solicitado_por ON contratos(solicitado_por_id);

CREATE TABLE contrato_aprobaciones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contrato_id UUID NOT NULL REFERENCES contratos(id) ON DELETE CASCADE,
  orden INT NOT NULL,
  nombre_paso TEXT NOT NULL,
  aprobador_id UUID REFERENCES usuarios(id),
  rol_requerido rol_usuario,
  decision decision_aprobacion NOT NULL DEFAULT 'pendiente',
  comentarios TEXT,
  decidido_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (contrato_id, orden)
);

CREATE TABLE contrato_documentos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contrato_id UUID NOT NULL REFERENCES contratos(id) ON DELETE CASCADE,
  nombre_archivo TEXT NOT NULL,
  ruta_archivo TEXT NOT NULL,
  version INT NOT NULL DEFAULT 1,
  categoria categoria_documento NOT NULL DEFAULT 'borrador',
  subido_por_id UUID NOT NULL REFERENCES usuarios(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contrato_id UUID REFERENCES contratos(id),
  usuario_id UUID REFERENCES usuarios(id),
  accion TEXT NOT NULL,
  detalle TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Franquicias: un tipo de contrato se marca es_franquicia = true y, al elegirlo,
-- el formulario despliega estos campos adicionales (1:1 con contratos). Las
-- columnas *_avisado son control interno del programador de notificaciones
-- (src/utils/franquicias.js) para no reenviar el mismo aviso cada día.
-- ---------------------------------------------------------------------------

ALTER TABLE tipos_contrato ADD COLUMN es_franquicia BOOLEAN NOT NULL DEFAULT false;

CREATE TABLE contrato_franquicia_detalles (
  contrato_id UUID PRIMARY KEY REFERENCES contratos(id) ON DELETE CASCADE,

  -- Términos financieros
  cuota_inicial NUMERIC(14,2),
  regalias_porcentaje NUMERIC(5,2),
  fondo_mercadeo_porcentaje NUMERIC(5,2),
  periodicidad_pago_regalias TEXT, -- 'mensual' | 'trimestral' | 'semestral' | 'anual'
  fecha_proximo_pago_regalias DATE,
  dias_aviso_pago_regalias INT NOT NULL DEFAULT 7,
  pago_regalias_avisado BOOLEAN NOT NULL DEFAULT false,

  -- Territorio y exclusividad
  territorio TEXT,
  radio_exclusividad_km NUMERIC(6,2),
  direccion_punto TEXT,

  -- Plazos y renovación
  fecha_limite_apertura DATE,
  dias_aviso_apertura INT NOT NULL DEFAULT 30,
  apertura_avisada BOOLEAN NOT NULL DEFAULT false,
  numero_renovaciones_permitidas INT,
  condiciones_renovacion TEXT,
  dias_aviso_renovacion INT NOT NULL DEFAULT 60,

  -- Cumplimiento y garantías
  fecha_proxima_auditoria DATE,
  dias_aviso_auditoria INT NOT NULL DEFAULT 15,
  auditoria_avisada BOOLEAN NOT NULL DEFAULT false,
  polizas_seguro_requeridas TEXT,
  garantia_personal BOOLEAN NOT NULL DEFAULT false,
  garante_nombre TEXT,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_franquicia_pago_regalias ON contrato_franquicia_detalles(fecha_proximo_pago_regalias);
CREATE INDEX idx_franquicia_apertura ON contrato_franquicia_detalles(fecha_limite_apertura);
CREATE INDEX idx_franquicia_auditoria ON contrato_franquicia_detalles(fecha_proxima_auditoria);

-- ---------------------------------------------------------------------------
-- Versionamiento de documentos: cada fila de contrato_documentos sigue siendo un
-- archivo físico, pero ahora las versiones del "mismo" documento (p.ej. varias
-- versiones firmadas de un mismo anexo) comparten grupo_id. es_version_actual = true
-- marca cuál es la vigente dentro de su grupo (así el expediente puede listar solo las
-- vigentes por default y expandir el historial completo por grupo_id bajo demanda).
-- reemplaza_a_id apunta a la versión anterior del mismo grupo (o NULL si es la v1).
-- origen distingue los documentos generados automáticamente desde una plantilla
-- (ver plantillas_tipo_contrato más abajo) de los subidos a mano.
-- ---------------------------------------------------------------------------

ALTER TABLE contrato_documentos ADD COLUMN grupo_id UUID;
UPDATE contrato_documentos SET grupo_id = id WHERE grupo_id IS NULL;
ALTER TABLE contrato_documentos ALTER COLUMN grupo_id SET NOT NULL;

ALTER TABLE contrato_documentos ADD COLUMN reemplaza_a_id UUID REFERENCES contrato_documentos(id);
ALTER TABLE contrato_documentos ADD COLUMN es_version_actual BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE contrato_documentos ADD COLUMN origen TEXT NOT NULL DEFAULT 'manual'; -- 'manual' | 'plantilla'

CREATE INDEX idx_documentos_grupo ON contrato_documentos(grupo_id);
CREATE INDEX idx_documentos_contrato_actual ON contrato_documentos(contrato_id, es_version_actual);

-- ---------------------------------------------------------------------------
-- Plantillas por tipo de contrato: un archivo Word (.docx) con marcadores {{llave}}
-- (ej. {{contraparteNombre}}, {{monto}}, y para franquicias {{regaliasPorcentaje}}, etc.)
-- que el backend puebla con los datos capturados del contrato (ver
-- src/utils/plantillas.js) para generar automáticamente un documento y agregarlo
-- al expediente como nueva versión (origen = 'plantilla'). Una plantilla por tipo
-- de contrato; volver a subir reemplaza la anterior.
-- ---------------------------------------------------------------------------

CREATE TABLE plantillas_tipo_contrato (
  tipo_contrato_id UUID PRIMARY KEY REFERENCES tipos_contrato(id) ON DELETE CASCADE,
  nombre_archivo TEXT NOT NULL,
  ruta_archivo TEXT NOT NULL,
  subido_por_id UUID NOT NULL REFERENCES usuarios(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Módulo de franquicias: los contratos de franquicia (uno por club) se administran
-- en su propio módulo (dashboard, listado y alta separados de "Contratos" general),
-- visible solo para super_admin/admin/juridico. `clubes` es el catálogo de sucursales;
-- cada contrato de franquicia se liga a exactamente un club vía
-- contrato_franquicia_detalles.club_id (nullable a nivel de BD para no romper filas
-- existentes creadas antes de este catálogo; el formulario de alta del módulo lo exige).
-- ---------------------------------------------------------------------------

CREATE TABLE clubes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre TEXT UNIQUE NOT NULL,
  direccion TEXT,
  activo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE contrato_franquicia_detalles ADD COLUMN club_id UUID REFERENCES clubes(id);
CREATE INDEX idx_franquicia_club ON contrato_franquicia_detalles(club_id);

-- ---------------------------------------------------------------------------
-- Al crear un usuario se le puede exigir que cambie su contraseña en su primer login
-- (checkbox marcado por default en el alta). Default FALSE a nivel de columna para no
-- forzar el cambio a usuarios ya existentes creados antes de este campo.
-- ---------------------------------------------------------------------------
ALTER TABLE usuarios ADD COLUMN debe_cambiar_password BOOLEAN NOT NULL DEFAULT false;

-- ---------------------------------------------------------------------------
-- Integración con doc2sign (firma electrónica NOM-151, ver backend/src/doc2signClient.js y
-- backend/src/utils/firmaElectronica.js). Un documento del expediente (contrato_documentos) se
-- puede mandar a firma; el resultado se guarda en las mismas filas para no crear un módulo
-- aparte. doc2sign_firmado_en / doc2sign_rechazado_en son la marca de "ya no sigas revisando
-- este documento" para el job periódico (NULL = todavía en proceso).
-- ---------------------------------------------------------------------------
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_documento_id UUID;
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_estatus TEXT;
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_firmantes JSONB;
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_enviado_por_id UUID REFERENCES usuarios(id);
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_enviado_at TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_actualizado_at TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_firmado_en TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN doc2sign_rechazado_en TIMESTAMPTZ;
CREATE INDEX idx_contrato_documentos_doc2sign_id ON contrato_documentos(doc2sign_documento_id)
  WHERE doc2sign_documento_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Se reemplaza por completo la integración de firma electrónica: doc2sign (PSC World, de
-- paga, NOM-151) se sustituye por DocuSeal (open-source, self-hosted, sin costo de licencia
-- — ver backend/src/docusealClient.js). Importante: DocuSeal es firma electrónica SIMPLE, NO
-- tiene certificación NOM-151 como sí tenía doc2sign; es una decisión consciente de costo vs.
-- certeza legal, confirmada con el usuario. Se quitan las columnas doc2sign_* (ya sin uso, el
-- código que las llenaba ya no existe) y se agregan sus equivalentes docuseal_*, mismo patrón
-- que antes: docuseal_firmado_en / docuseal_rechazado_en son la marca de "ya no sigas
-- revisando este documento" para el job periódico (NULL = todavía en proceso).
-- docuseal_submission_id es TEXT (no UUID): los ids de "submission" de DocuSeal son numéricos
-- (ej. "5"), no GUIDs.
-- ---------------------------------------------------------------------------
DROP INDEX IF EXISTS idx_contrato_documentos_doc2sign_id;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_documento_id;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_estatus;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_firmantes;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_enviado_por_id;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_enviado_at;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_actualizado_at;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_firmado_en;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS doc2sign_rechazado_en;

ALTER TABLE contrato_documentos ADD COLUMN docuseal_submission_id TEXT;
ALTER TABLE contrato_documentos ADD COLUMN docuseal_estatus TEXT;
ALTER TABLE contrato_documentos ADD COLUMN docuseal_firmantes JSONB;
ALTER TABLE contrato_documentos ADD COLUMN docuseal_enviado_por_id UUID REFERENCES usuarios(id);
ALTER TABLE contrato_documentos ADD COLUMN docuseal_enviado_at TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN docuseal_actualizado_at TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN docuseal_firmado_en TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN docuseal_rechazado_en TIMESTAMPTZ;
CREATE INDEX idx_contrato_documentos_docuseal_id ON contrato_documentos(docuseal_submission_id)
  WHERE docuseal_submission_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Se reemplaza por completo la integración de firma electrónica: DocuSeal (self-hosted) se
-- sustituye por Documenso (open-source, self-hosted, sin costo de licencia — ver
-- backend/src/documensoClient.js). Motivo: se descubrió en vivo (y se confirmó contra la
-- documentación oficial de DocuSeal) que su edición Community/gratuita bloquea justo el
-- endpoint que esta app necesita (crear una firma nueva a partir de un PDF recién subido, con
-- varios firmantes) detrás de su plan de pago "Pro Edition" — ver
-- https://www.docuseal.com/docs/api. Documenso deja esa misma funcionalidad núcleo en su
-- edición Community, sin costo. Documenso sigue siendo firma electrónica SIMPLE, NO tiene
-- certificación NOM-151 (mismo punto que ya aplicaba con DocuSeal). Se quitan las columnas
-- docuseal_* (ya sin uso, el código que las llenaba ya no existe) y se agregan sus
-- equivalentes documenso_*, mismo patrón que antes: documenso_firmado_en /
-- documenso_rechazado_en son la marca de "ya no sigas revisando este documento" para el job
-- periódico (NULL = todavía en proceso). documenso_submission_id es TEXT (no UUID): los ids de
-- "envelope" de Documenso son alfanuméricos con prefijo (ej. "envelope_abc123xyz").
-- ---------------------------------------------------------------------------
DROP INDEX IF EXISTS idx_contrato_documentos_docuseal_id;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_submission_id;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_estatus;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_firmantes;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_enviado_por_id;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_enviado_at;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_actualizado_at;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_firmado_en;
ALTER TABLE contrato_documentos DROP COLUMN IF EXISTS docuseal_rechazado_en;

ALTER TABLE contrato_documentos ADD COLUMN documenso_submission_id TEXT;
ALTER TABLE contrato_documentos ADD COLUMN documenso_estatus TEXT;
ALTER TABLE contrato_documentos ADD COLUMN documenso_firmantes JSONB;
ALTER TABLE contrato_documentos ADD COLUMN documenso_enviado_por_id UUID REFERENCES usuarios(id);
ALTER TABLE contrato_documentos ADD COLUMN documenso_enviado_at TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN documenso_actualizado_at TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN documenso_firmado_en TIMESTAMPTZ;
ALTER TABLE contrato_documentos ADD COLUMN documenso_rechazado_en TIMESTAMPTZ;
CREATE INDEX idx_contrato_documentos_documenso_id ON contrato_documentos(documenso_submission_id)
  WHERE documenso_submission_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Solicitud dinámica por tipo de contrato: a partir de ahora, "Confidencialidad (NDA)" y
-- "Servicios Profesionales" piden campos propios (además de una versión más completa de los
-- datos de la contraparte), documentados por jurídico. Mismo patrón que franquicias:
-- tipos_contrato.es_* marca el tipo y una tabla de detalle 1:1 con contratos guarda sus
-- campos. Todas las columnas quedan NULLable a nivel de BD: lo obligatorio se valida en la
-- app (ver validarContrato en frontend/src/components/ContratoForm.jsx), igual que ya pasa
-- con contrato_franquicia_detalles.
-- ---------------------------------------------------------------------------

ALTER TABLE tipos_contrato ADD COLUMN es_nda BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE tipos_contrato ADD COLUMN es_servicios BOOLEAN NOT NULL DEFAULT false;

UPDATE tipos_contrato SET es_nda = true WHERE nombre = 'Confidencialidad (NDA)';
UPDATE tipos_contrato SET es_servicios = true WHERE nombre = 'Servicios Profesionales';

-- Datos ampliados de la contraparte (persona física/moral) + administrador interno del
-- contrato. El nombre, RFC, contacto y correo de la contraparte se siguen guardando en las
-- columnas planas que ya existían en "contratos" (contraparte_nombre, contraparte_rfc,
-- contraparte_contacto, contraparte_email); aquí solo vive lo que esos campos no cubrían.
CREATE TABLE contrato_contraparte_detalles (
  contrato_id UUID PRIMARY KEY REFERENCES contratos(id) ON DELETE CASCADE,
  tipo_persona TEXT, -- 'fisica' | 'moral'

  representante_legal_nombre TEXT, -- solo persona moral

  nacionalidad TEXT, -- solo persona física
  curp TEXT,          -- solo persona física

  domicilio TEXT, -- ambos tipos de persona

  administrador_interno_nombre TEXT, -- "Datos internos"

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Solicitud de NDA.
CREATE TABLE contrato_nda_detalles (
  contrato_id UUID PRIMARY KEY REFERENCES contratos(id) ON DELETE CASCADE,
  descripcion_proyecto TEXT, -- proyecto/negociación/operación que origina el intercambio
  tipo_informacion TEXT,     -- qué tipo de información se pretende compartir
  fecha_firma DATE,
  comentarios TEXT,          -- comentario adicional [Opcional]
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Solicitud de prestación de servicios / servicios especializados. Cuando lugar_prestacion =
-- 'instalaciones_fpt' se vuelve "servicios especializados": el formulario exige además
-- lugar_exacto, repse, registro_patronal y numero_trabajadores (validado en la app, no aquí).
CREATE TABLE contrato_servicios_detalles (
  contrato_id UUID PRIMARY KEY REFERENCES contratos(id) ON DELETE CASCADE,
  descripcion_servicios TEXT,
  actividades_prestador TEXT,
  cronograma TEXT, -- hitos o fechas de entrega
  lugar_prestacion TEXT, -- 'instalaciones_proveedor' | 'remoto' | 'ubicacion_terceros' | 'instalaciones_fpt'

  -- Solo si lugar_prestacion = 'instalaciones_fpt' ("servicios especializados")
  lugar_exacto TEXT,
  repse TEXT,
  registro_patronal TEXT,
  numero_trabajadores INT,

  -- Contraprestación (importe y moneda ya viven en contratos.monto / contratos.moneda)
  incluye_iva BOOLEAN,
  condiciones_pago TEXT,
  garantias TEXT, -- [Opcional]

  fecha_firma DATE,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Documentos con nombre específico del checklist de jurídico (ej. "escritura_constitutiva",
-- "repse", "proyecto_nda"; ver DOCUMENTOS_REQUERIDOS en ContratoForm.jsx). NULL = documento
-- genérico sin etiquetar, el comportamiento de siempre.
ALTER TABLE contrato_documentos ADD COLUMN etiqueta TEXT;

-- ---------------------------------------------------------------------------
-- sep 2026: renombrar "Servicios Profesionales", cancelación de solicitudes/contratos vigentes,
-- y "Documento firmado manual" (adjuntar un contrato con firma física, solo jurídico).
-- ---------------------------------------------------------------------------

-- Ya existía como fila (es_servicios = true); se renombra en vez de crear un tipo nuevo, para no
-- perder la relación con los contratos que ya lo usan. (Esto también se puede hacer desde la app,
-- en Administración → Tipos de contrato → Editar — esta línea es solo para que quede igual si se
-- levanta una instalación nueva a partir de este script.)
UPDATE tipos_contrato SET nombre = 'Prestación de servicios' WHERE nombre = 'Servicios Profesionales';

-- "Documento firmado manual": un valor más de categoria_documento, junto a los que ya había.
-- OJO: en Postgres, ALTER TYPE ... ADD VALUE no puede ir en la misma transacción que una
-- sentencia que ya use ese valor nuevo — si tu cliente de SQL agrupa todo el archivo en una sola
-- transacción, corre esta línea sola primero y el resto después.
ALTER TYPE categoria_documento ADD VALUE IF NOT EXISTS 'firmado_manual';

-- Cancelación: de una solicitud (por quien la levantó) o de un contrato vigente/activo (solo
-- jurídico, con motivo obligatorio — ver POST .../cancelar-solicitud y .../cancelar-contrato en
-- routes/contratos.js). Ambos casos dejan contratos.estatus = 'cancelado' (ya existía en el enum);
-- estas columnas son las que permiten distinguir quién/cuándo/por qué después.
ALTER TABLE contratos ADD COLUMN cancelado_en TIMESTAMPTZ;
ALTER TABLE contratos ADD COLUMN cancelado_por_id UUID REFERENCES usuarios(id);
ALTER TABLE contratos ADD COLUMN motivo_cancelacion TEXT;

-- ---------------------------------------------------------------------------
-- sep 2026: "jefe directo" por persona + flujo de autorización dinámico
-- (Cabeza del Área Solicitante -> Cabeza de Jurídico -> CFO -> CEO, con posibilidad de
-- "Regresar al solicitante para corrección" en vez de solo Aprobar/Rechazar). Ver
-- utils/flujoEngine.js, routes/contratos.js (decidir) y routes/flujoPlantillas.js.
-- No aplica al módulo de franquicias (flujo propio, sin cambios).
-- ---------------------------------------------------------------------------

-- Jefe directo de cada persona: quien resuelve dinámicamente el paso "Cabeza del Área
-- Solicitante" de cualquier contrato que esa persona levante (ver flujoEngine.generarAprobaciones).
-- Se pide obligatorio desde el formulario de alta (frontend/src/pages/admin/Usuarios.jsx) para
-- que no quede en blanco por descuido, pero la columna en sí es NULLable para no romper las
-- cuentas que ya existían antes de este cambio (hay que editarlas para completarlo).
ALTER TABLE usuarios ADD COLUMN jefe_directo_id UUID REFERENCES usuarios(id);

-- Un paso de flujo_pasos ahora puede señalar "el aprobador es el jefe directo de quien levantó
-- ESTE contrato" (resuelto por contrato, no fijo en la plantilla) en vez de un rol_aprobador o un
-- aprobador_id fijos. Y cada paso indica si, al no estar de acuerdo, quien decide puede "regresar"
-- la solicitud al solicitante para que la corrija y la reenvíe (en vez de solo poder rechazarla
-- de forma definitiva) — en el diagrama acordado, el primer paso (jefe directo) no lo permite,
-- los siguientes tres sí.
ALTER TABLE flujo_pasos ADD COLUMN es_jefe_directo_solicitante BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE flujo_pasos ADD COLUMN permite_regresar BOOLEAN NOT NULL DEFAULT TRUE;

-- Se reemplaza el CHECK original (exigía rol_aprobador O aprobador_id) por uno que también acepta
-- es_jefe_directo_solicitante = true como una tercera forma válida de resolver el aprobador. Se
-- busca el nombre real de la restricción en vez de asumirlo, por si Postgres la nombró distinto.
DO $$
DECLARE
  nombre_restriccion text;
BEGIN
  SELECT conname INTO nombre_restriccion
  FROM pg_constraint
  WHERE conrelid = 'flujo_pasos'::regclass
    AND contype = 'c'
    AND pg_get_constraintdef(oid) ILIKE '%rol_aprobador%aprobador_id%';
  IF nombre_restriccion IS NOT NULL THEN
    EXECUTE format('ALTER TABLE flujo_pasos DROP CONSTRAINT %I', nombre_restriccion);
  END IF;
END $$;
ALTER TABLE flujo_pasos ADD CONSTRAINT flujo_pasos_aprobador_check
  CHECK (rol_aprobador IS NOT NULL OR aprobador_id IS NOT NULL OR es_jefe_directo_solicitante = true);

-- contrato_aprobaciones copia permite_regresar del paso al generarse (ver generarAprobaciones),
-- así el frontend sabe si mostrar el botón "Regresar" para el paso pendiente actual sin tener que
-- volver a consultar la plantilla.
ALTER TABLE contrato_aprobaciones ADD COLUMN permite_regresar BOOLEAN NOT NULL DEFAULT TRUE;

-- Nueva decisión posible en contrato_aprobaciones.decision, junto a aprobado/rechazado/omitido:
-- "regresado" dejarlo el contrato en estatus 'en_revision' (ya existía en estatus_contrato, sin
-- usarse) en vez de 'rechazado', para que el solicitante lo corrija y reenvíe el mismo flujo desde
-- el paso 1. OJO: igual que con 'firmado_manual' antes, ALTER TYPE ... ADD VALUE no puede ir en la
-- misma transacción que algo que ya use el valor nuevo — si tu cliente agrupa todo en una sola
-- transacción, corre esta línea sola primero.
ALTER TYPE decision_aprobacion ADD VALUE IF NOT EXISTS 'regresado';

-- sep 2026: roles CEO y CFO (Usuarios -> botón "Editar", solo Super Admin puede asignarlos).
-- Son sobre todo un "puesto" informativo: el flujo de autorización ya identifica a estas
-- personas por id fijo (aprobador_id en flujo_pasos), no por rol. Tienen el mismo acceso
-- administrativo que 'admin' (ver requireRole en las rutas). OJO: igual que con 'regresado'
-- arriba, cada ALTER TYPE ... ADD VALUE debe correr solo, no junto con otro que ya use el
-- valor nuevo en la misma transacción.
ALTER TYPE rol_usuario ADD VALUE IF NOT EXISTS 'ceo';
ALTER TYPE rol_usuario ADD VALUE IF NOT EXISTS 'cfo';

-- sep 2026: Cabeza de Jurídico (Roberto Sacasa) — único rol (junto a super_admin) que autoriza
-- del lado de Jurídico: cancelar un contrato vigente y adjuntar "Documento firmado manual"
-- (antes cualquier persona con rol 'juridico' podía). 'juridico' normal conserva la misma
-- visibilidad de siempre sobre cualquier contrato, pero ya no puede editarlos/cancelarlos; a
-- cambio puede comentar mientras la solicitud está en borrador/en_revision/en_autorizacion (ver
-- ESTATUS_SOLICITUD y ROLES_AUTORIDAD_JURIDICA/ROLES_NIVEL_ADMIN en el backend). Mismo nivel de
-- acceso administrativo que 'admin', igual que CEO/CFO arriba. OJO: como con 'ceo'/'cfo' arriba,
-- corre esta línea sola, no junto con algo que ya use el valor nuevo en la misma transacción.
ALTER TYPE rol_usuario ADD VALUE IF NOT EXISTS 'cabeza_juridico';

-- Persona de rol "juridico" (o Cabeza de Jurídico) asignada como responsable de dar seguimiento
-- a ESTE contrato en particular — solo informativo, no cambia quién aprueba el flujo. Solo
-- Cabeza de Jurídico o super_admin puede fijarlo/cambiarlo (ver PATCH /api/contratos/:id/
-- juridico-asignado); visible para cualquiera que pueda ver el contrato (GET / y GET /:id).
ALTER TABLE contratos ADD COLUMN juridico_asignado_id UUID REFERENCES usuarios(id);

-- Hilo de comentarios/notas internas sobre un contrato — distinto del comentario que ya se
-- guarda al decidir un paso de autorización (contrato_aprobaciones.comentarios). Cualquiera que
-- pueda ver el contrato puede leerlos; para escribir uno ver POST .../comentarios (roles de
-- nivel admin siempre; jurídico normal solo mientras la solicitud está en borrador/en_revision/
-- en_autorizacion).
CREATE TABLE contrato_comentarios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contrato_id UUID NOT NULL REFERENCES contratos(id) ON DELETE CASCADE,
  usuario_id UUID NOT NULL REFERENCES usuarios(id),
  comentario TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX contrato_comentarios_contrato_id_idx ON contrato_comentarios(contrato_id);
